import db from "./utils/connection.js";
import express from "express";
import { Sequelize } from "sequelize";
import "./models/index.js"
import User from "./models/UserModels.js";
import Mochi from "./models/MochiModels.js";
import Order from "./models/OrderModels.js";
import BahanBaku from "./models/BahanModels.js";
import Payment from "./models/PaymentModels.js";

const port = process.env.PORT;
const app = express();

// await Mochi.sync({force:true});
// app.use(express.json());
// app.use(bodyParser.json())



app.listen(port, () => {
    console.log(`server running at ${port}`)
});