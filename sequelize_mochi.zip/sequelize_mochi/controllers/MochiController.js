import Order from "../models/OrderModels.js";
import BahanBaku from "../models/BahanModels.js";
import Mochi from "../models/MochiModels.js";

export const createMochi = async (req, res) => {
    try {
      const { id, name, flavor, price, description } = req.body;
      const mochi = await Mochi.create(
        { id, name, flavor, price, description },
        // { where: { id } }
      );
      res.status(201).json(mochi);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };
  
  export const updateMochi = async (req, res) => {
    try {
      // const { id } = req.params;
      const { id, name, flavor, price, description } = req.body;
      const [updated] = await Mochi.update(
        { id, name, flavor, price, description },
      );
      if (updated) {
        const updateMochi = await Mochi.findByPk(id);
        res.status(200).json(updateMochi);
      } else {
        res.status(404).json({ message: "Mocih Tidak Ditemukan" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  export const deleteMochi = async (req, res) => {
    try {
      // const { id } = req.params;
      const { id, name, flavor, price, description } = req.body;
      // const deleted = await Mochi.destroy({ where: { id } });
      const [deleted] = await Mochi.destroy(
        { id, name, flavor, price, description },
        { where: { id } }
      );
      if (deleted) {
        res.status(204).end();
      } else {
        res.status(404).json({ message: "Mochi Tidak Ditemukan" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  export const getMochi = async (req, res) => {
    try {
      const mochi = await Mochi.findAll();
      res.status(200).json(mochi);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  export const getMochiById = async (req, res) => {
    try {
      // const { id } = req.params;
      const { id, name, flavor, price, description } = req.body;
      // const mochi = await Mochi.findByPk(id);
      const [findByPk] = await Mochi.findByPk(
        { id, name, flavor, price, description },
        { where: { id } }
      );
      if (!mochi) return res.status(404).json({ message: "Mochi tidak ditemukan" });
      res.status(200).json(film);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };