import Order from "../models/OrderModels.js";
import OrderItem from "../models/BahanModels.js";
import Payment from "../models/PaymentModels.js";

export const createOrder = async (req, res) => {
    try {
      const { orderId, mochiId, quantity, price } = req.body;
      const order = await Order.create(
        { orderId, mochiId, quantity, price }
      );
      res.status(201).json(order);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };
  
  export const updateOrder = async (req, res) => {
    try {
    //   const { id } = req.params;
      const { orderId, mochiId, quantity, price } = req.body;
      const [updated] = await Order.update(
        {  orderId, mochiId, quantity, price  },
        { where: { id } }
      );
      if (updated) {
        const updateOrder = await Order.findByPk(id);
        res.status(200).json(updateOrder);
      } else {
        res.status(404).json({ message: "Order Tidak Ditemukan" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  export const deleteOrder = async (req, res) => {
    try {
      // const { id } = req.params;
      const { orderId, mochiId, quantity, price } = req.body;
      // const deleted = await Mochi.destroy({ where: { id } });
      const [deleted] = await Order.destroy(
        {  orderId, mochiId, quantity, price },
        { where: { id } }
      );
      if (deleted) {
        res.status(204).end();
      } else {
        res.status(404).json({ message: "Order Tidak Ditemukan" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  export const getOrder = async (req, res) => {
    try {
      const order = await Order.findAll();
      res.status(200).json(order);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  export const getOrderById = async (req, res) => {
    try {
      // const { id } = req.params;
      const { orderId, mochiId, quantity, price } = req.body;
      // const mochi = await Mochi.findByPk(id);
      const [findByPk] = await Order.findByPk(
        { orderId, mochiId, quantity, price },
        { where: { id } }
      );
      if (!order) return res.status(404).json({ message: "Order tidak ditemukan" });
      res.status(200).json(film);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };