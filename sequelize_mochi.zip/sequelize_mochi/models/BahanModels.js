import Payment from "./PaymentModels.js";
import Mochi from "./MochiModels.js"
// import { Sequelize } from "sequelize";
import {DataTypes} from "sequelize";
import db from "../utils/connection.js";

const BahanBaku = db.define('BahanBaku', {
    BahanBakuId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    TepungKanji: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    TepungKetan: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    PastaCoklat: {
      type: DataTypes.FLOAT,
      allowNull: true
    },
    SelaiCoklat: {
      type: DataTypes.INTEGER,
      allowNull: true,
    }
  });
  
  BahanBaku.belongsTo( Payment, {
    foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
  });
  Payment.belongsTo( BahanBaku, {
    foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
  });

  BahanBaku.hasMany( Mochi, {
    foreignKey: "orderId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
  });
  Mochi.belongsTo( BahanBaku, {
    foreignKey: "orderId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
  });

  export default BahanBaku;