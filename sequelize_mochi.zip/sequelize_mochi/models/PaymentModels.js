import {DataTypes} from "sequelize";
import db from "../utils/connection.js";
import Mochi from "./MochiModels.js";

const Payment = db.define('Payment', {
    orderId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    paymentMethod: {
      type: DataTypes.ENUM('credit_card', 'bank_transfer', 'cash_on_delivery', 'qr_code'),
      allowNull: false
    },
    paymentStatus: {
      type: DataTypes.ENUM('paid', 'unpaid', 'refunded'),
      allowNull: false,
      defaultValue: 'unpaid'
    },
    paymentDate: {
      type: DataTypes.DATE,
      allowNull: true
    }
  });
  
// Relasi dengan Mochi
Payment.hasMany( Mochi, {
    foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Payment.belongsTo( Mochi, {
    foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});

export default Payment;
