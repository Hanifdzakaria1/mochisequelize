import db from "../utils/connection.js"
import User from "../models/UserModels.js";
import Mochi from "./MochiModels.js"
import BahanBaku from "./BahanModels.js";
import Order from "./OrderModels.js";
import Payment from "./PaymentModels.js";

await User.sync();
await Mochi.sync();
await BahanBaku.sync();
await Order.sync();
await Payment.sync(); 
await db.sync();