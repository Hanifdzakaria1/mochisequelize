import {DataTypes} from "sequelize";
import db from "../utils/connection.js";
import Mochi from "./MochiModels.js";
import Payment from "./PaymentModels.js";
import BahanBaku from "./BahanModels.js";


const Order = db.define('Order', {  
    orderId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    mochiId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    quantity: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    price: {
      type: DataTypes.FLOAT,
      allowNull: false
    }
});

// Relasi dengan Payment
BahanBaku.belongsTo(Payment, {
    foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Payment.belongsTo(BahanBaku, {
    foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});

// Relasi dengan Mochi
BahanBaku.hasMany(Mochi, {
    foreignKey: "orderId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Mochi.belongsTo(BahanBaku, {
    foreignKey: "orderId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
export default Order;
