import Mochi from "../../models/MochiModels.js";
import User from "../../models/UserModels.js";
import BahanBaku from "../../models/BahanModels.js";
import Order from "../../models/OrderModels.js";
import Payment from "../../models/PaymentModels.js";

export default async function clean() {
    await User.destroy({
        where:{},
        force: true,
        cascade: true,
    });
    await Mochi.destroy({
        where:{},
        force: true,
        cascade: true,
    });
    await BahanBaku.destroy({
        where: {},
        force: true,
        cascade: true,
    });
    await Order.destroy({
        where: {},
        force: true,
        cascade: true,
    });
    await Payment.destroy({
        where: {},
        force: true,
        cascade: true,
    });
};